# AnimationDemo for SSD1306

![AnimationDemo](https://user-images.githubusercontent.com/6020549/165405896-e37ff7f1-f118-4090-95e9-6f940989c6a4.JPG)

I borrowed the BIT MAP data from [here](https://www.mischianti.org/2021/07/14/ssd1306-oled-display-draw-images-splash-and-animations-2/).   

__Wire cables should be as short as possible.__   

__Flip upside down cannot be enabled.__   

I used a 10 cm wire cable.   
However, it is sometimes affected by noise.   

