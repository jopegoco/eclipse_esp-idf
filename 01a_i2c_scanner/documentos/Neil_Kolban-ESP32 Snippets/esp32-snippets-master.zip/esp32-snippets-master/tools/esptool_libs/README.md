# Esptool libraries
The Espressif awesome esptool performs just about anything you may want to do relating to ESP32 programming over UART.  It can write to flash, write to memory, erase flash and a world of other features.  The specification of the protocol can be found in the `esptool` github project Wiki.

This section of this repository hosts libraries for working with this protocol.  There is an implementation in Node.js and more to come including C and C++.