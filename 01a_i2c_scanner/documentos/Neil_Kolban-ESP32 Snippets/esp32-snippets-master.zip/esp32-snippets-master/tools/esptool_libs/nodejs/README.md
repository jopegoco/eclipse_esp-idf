# NodeJS ESP Tools

The `build.js` tool is used to take the `stub_flasher_32.elf` and break it apart into the separate files that need to be individually pushed to ESP32 RAM for execution.