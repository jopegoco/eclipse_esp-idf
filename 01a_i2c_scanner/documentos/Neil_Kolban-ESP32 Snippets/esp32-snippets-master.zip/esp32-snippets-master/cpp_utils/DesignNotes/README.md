# Design Notes
Here is where we keep some of our design documents.