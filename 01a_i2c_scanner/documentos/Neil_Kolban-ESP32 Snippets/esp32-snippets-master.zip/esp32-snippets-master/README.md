# ESP32 Snippets
This repository is no longer being actively maintained.  It was previously archived to make it read-only but, by request, has been un-archived so that others may continue to post comments and issues.  However, please understand that issues raised are unlikely to be resolved against this repository.
