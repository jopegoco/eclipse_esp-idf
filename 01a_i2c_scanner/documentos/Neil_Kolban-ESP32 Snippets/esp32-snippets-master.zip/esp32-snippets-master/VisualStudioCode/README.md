These are file for Microsoft Visual Studio Code and can be copied into your `.vscode` project folder.  For more information on this area, see:

* [VSCode JTAG Debugging of ESP32 - Part 2](https://gojimmypi.blogspot.com/2017/05/vscode-remote-jtag-debugging-of-esp32.html)
* [Deous/VSC-Guide-for-esp32](https://github.com/Deous/VSC-Guide-for-esp32)