/*
 * GPIODriver.h
 *
 *  Created on: May 27, 2018
 *      Author: kolban
 */

#ifndef MAIN_GPIODRIVER_H_
#define MAIN_GPIODRIVER_H_

class GPIODriver {
public:
	GPIODriver();
	virtual ~GPIODriver();
	void run();
};

#endif /* MAIN_GPIODRIVER_H_ */
