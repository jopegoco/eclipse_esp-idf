# Watchdogs
This is a sample application that illustrates the capabilities of watchdogs and watchdog processing.

A related YouTube video is available here:

https://www.youtube.com/watch?v=C2xF3O6qkbg