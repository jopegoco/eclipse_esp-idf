extern void doGPS();

int app_main(void)
{
  doGPS();
  return 0;
}
