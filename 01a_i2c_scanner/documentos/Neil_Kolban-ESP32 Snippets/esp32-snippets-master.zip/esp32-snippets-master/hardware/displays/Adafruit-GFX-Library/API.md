* drawBitmap
```
drawBitmap(x, y, bitmap, w, h, color)
```

* drawChar
Characters are 5x8
```
drawChar(x, y, c, color, bg, size)
```

* drawCircle
```
drawCircle(x, y, r, color)
```

* drawLine
```
drawLine(x1, y1, x2, y2, color)
```

* drawPixel
```
drawPixel(x,y,color)
```

* drawRect
```
drawRect(x, y, w, h, color)
```

* drawRoundRect
```
drawRoundRect(x, y, w, h, r, color)
```

* fillCircle
```
fillCircle(x, y, r, color)
```

* fillRect
```
fillRect(x, y, w, h, color)
```

* fillRoundRect
```
fillRoundRect(x, y, w, h, r, color)
```

* fillScreen
```
fillScreen(color)
```

* setCursor
```
setCursor(x, y)
```

* setRotation
```
setRotation(rotation)
```

* setTextColor
```
setTextColor(color)
setTextColor(color, backgroundColor)
```

* setTextSize
```
setTextSize(size)
```

* setTextWrap
```
setTextWrap(w)
```