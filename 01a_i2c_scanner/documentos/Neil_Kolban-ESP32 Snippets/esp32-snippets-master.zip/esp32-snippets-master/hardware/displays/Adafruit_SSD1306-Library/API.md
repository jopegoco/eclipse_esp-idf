* begin
```
void begin()
```

* clearDisplay
```
void clearDisplay()
```

* dim
```
void dim(boolean)
```

* display
```
void display()
```

* invertDisplay
Invert the visual of the display.  Since this device is black and white which an off background of
black the effect is to draw in black on a background of white.

```
void invertDisplay(boolean)
```

* startscrolldiagonalleft
* startscrolldiagonalright
* startscrollleft
* startscrollright
* scopscroll