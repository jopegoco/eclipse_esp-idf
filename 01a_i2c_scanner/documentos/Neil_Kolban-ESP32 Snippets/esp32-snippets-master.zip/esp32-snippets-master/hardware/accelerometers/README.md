#Accelerometers
An accelerometer detects acceleration and in some cases gyro scopic movement.

See also the C++ class for MPU-6050 support.