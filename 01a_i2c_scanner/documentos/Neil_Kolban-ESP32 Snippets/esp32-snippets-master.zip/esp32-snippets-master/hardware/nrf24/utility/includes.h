  
#ifndef __RF24_INCLUDES_H__
#define __RF24_INCLUDES_H__

#define RF24_ESP_IDF
#include "ESP_IDF/RF24_arch_config.h"
#include "ESP_IDF/RF24_ESP_IDF.h"
#include "ESP_IDF/NRF24_spi.h"
#endif
